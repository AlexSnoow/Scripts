# Send-Email

## Описание
Функция отправки электронной почты через SMTP с использованием COM-объекта CDO (Collaboration Data Objects). Поддерживает аутентификацию, SSL и текстовые/HTML-сообщения.

## Синтаксис
```powershell
Send-Email [-SmtpServer] <string> [-From] <string> [-To] <string> [-Subject] <string> [-Body] <string> [[-Port] <int>] [-UseSSL <bool>] [[-Username] <string>] [[-Password] <string>] [-IsBodyHtml <bool>]
```

## Параметры
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| SmtpServer | string | Да | Адрес SMTP-сервера |
| From | string | Да | Адрес отправителя |
| To | string | Да | Адрес получателя (множественные через запятую) |
| Subject | string | Да | Тема письма |
| Body | string | Да | Тело сообщения |
| Port | int | Нет | Порт SMTP (по умолчанию: 25) |
| UseSSL | bool | Нет | Использовать SSL (по умолчанию: $false) |
| Username | string | Нет | Имя пользователя для аутентификации |
| Password | string | Нет | Пароль для аутентификации |
| IsBodyHtml | bool | Нет | Формат HTML для тела сообщения (по умолчанию: $false) |

## Возвращаемое значение
`[bool]` - `$true` при успешной отправке, `$false` при ошибке.

## Примеры использования
```powershell
# Простая отправка (без аутентификации)
Send-Email -SmtpServer "mail.company.local" -From "backup@company.local" -To "admin@company.local" -Subject "Отчёт" -Body "Резервное копирование завершено"

# Отправка с SSL и аутентификацией
Send-Email `
    -SmtpServer "smtp.gmail.com" `
    -Port 587 `
    -From "backup@gmail.com" `
    -To "admin@company.local" `
    -Subject "Отчёт" `
    -Body "<h1>Успех</h1>" `
    -Username "backup@gmail.com" `
    -Password "secret" `
    -UseSSL $true `
    -IsBodyHtml $true

# Множественные получатели
Send-Email -SmtpServer "mail.local" -From "script@local" -To "admin1@local, admin2@local" -Subject "Alert" -Body "Error occurred"
```

## Примечания
- Использует COM-объект `CDO.Message` (совместимость с PowerShell 2.0)
- Настраивает поля CDO Configuration для SMTP-соединения
- Поддерживает анонимную (`smtpauthenticate = 0`) и базовую (`smtpauthenticate = 1`) аутентификацию
- Таймаут соединения: 60 секунд
- Автоматически освобождает COM-объект через `Marshal.ReleaseComObject` в блоке `finally`
- При ошибке записывает сообщение в консоль и возвращает `$false`
- Множественные получатели указываются через запятую в параметре `-To`
- Применяется для отправки отчётов администраторам о результатах резервного копирования
- Не поддерживает вложения файлов (только текст/HTML)
