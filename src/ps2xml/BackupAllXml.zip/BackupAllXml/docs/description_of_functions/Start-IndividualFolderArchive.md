# Start-IndividualFolderArchive

## Описание
Функция индивидуальной архивации каждой подпапки источника в отдельный RAR-архив. Позволяет создавать отдельные архивы для каждой подпапки первого уровня с использованием настраиваемого шаблона именования, фильтров и исключений.

## Синтаксис
```powershell
Start-IndividualFolderArchive -ArchiverType <string> -ArchiverPath <string> -SourcePath <string> -DestinationPath <string> -ArchivePattern <string> [-FolderFilter <string>] [-ExcludeFolderPattern <string>] [-Parameters <string[]>] [-LogPath <string>] [-PCName <string>] [-JobName <string>]
```

## Параметры
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| ArchiverType | string | Да | Тип архиватора (поддерживается только "RAR") |
| ArchiverPath | string | Да | Путь к rar.exe |
| SourcePath | string | Да | Путь к директории источника |
| DestinationPath | string | Да | Путь к директории назначения для архивов |
| ArchivePattern | string | Да | Шаблон именования архивов |
| FolderFilter | string | Нет | Маска для фильтрации папок (например, `2026*`) |
| ExcludeFolderPattern | string | Нет | Маска исключения папок или спецзначение `today` |
| Parameters | string[] | Нет | Параметры для RAR.exe |
| LogPath | string | Нет | Путь к файлу лога архиватора |
| PCName | string | Нет | Имя компьютера (для замены в шаблоне) |
| JobName | string | Нет | Имя задания (для замены в шаблоне) |

## Шаблоны ArchivePattern
Поддерживает следующие переменные:
- `{PCName}` - имя компьютера
- `{JobName}` - имя задания
- `{SourceFolderName}` - имя исходной подпапки

## Спецзначения ExcludeFolderPattern
- `today` - автоматически исключает папку с именем текущей даты (формат `yyyyMMdd`)

## Возвращаемое значение
`[PSObject[]]` - массив объектов результатов архивации, каждый со свойствами:
- `SourceFolder` - имя исходной папки
- `SourceFolderFullPath` - полный путь к исходной папке
- `ArchivePath` - полный путь к созданному архиву
- `ArchiveSize` - размер архива в МБ
- `Duration` - длительность архивации папки (секунды)
- `Status` - статус: 'Success' или 'Error'
- `ExitCode` - код возврата RAR.exe
- `ErrorMessage` - сообщение об ошибке (для статуса 'Error')

## Примеры использования
```powershell
# Индивидуальная архивация всех подпапок
$results = Start-IndividualFolderArchive `
    -ArchiverType "RAR" `
    -ArchiverPath "C:\rar.exe" `
    -SourcePath "C:\data\logs" `
    -DestinationPath "C:\backup\rar" `
    -ArchivePattern "{PCName}_{JobName}_{SourceFolderName}.rar" `
    -ExcludeFolderPattern "today" `
    -PCName "SERVER01" `
    -JobName "BackupLogs"

foreach ($result in $results) {
    Write-Host "$($result.SourceFolder): $($result.Status)"
}
```

## Примечания
- Сканирует только подпапки первого уровня (без рекурсии)
- При наличии `FolderFilter` фильтрует папки по маске
- При `ExcludeFolderPattern = 'today'` исключает папку с текущей датой (для инкрементальных бэкапов)
- Для каждой папки создаёт отдельный архив
- Автоматически создаёт директорию назначения, если не существует
- Если шаблон не заканчивается на `.rar`, добавляет расширение автоматически
- Заменяет недопустимые символы в имени архива (`\/:*?"<>|`) на подчёркивание
- При ошибке архивации одной папки продолжает обработку остальных
- Возвращает результаты для всех папок (успешных и с ошибками)
- Подсчитывает и логирует общую статистику (успешно/ошибки)
