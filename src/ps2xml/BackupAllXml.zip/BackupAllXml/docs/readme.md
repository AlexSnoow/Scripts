# Скрипт резервного копирования Backup-rar-ps2.ps1

> **Версия:** 2.5 (RAR-only)  
> **Совместимость:** PowerShell 2.0 / Windows 7  
> **Дата:** 2026-04-10  
> **Конфигурация:** `Backup-Config-All.xml`

---

## Обзор

Автономный скрипт резервного копирования с поддержкой XML-конфигурации. Выполняет архивацию файлов и папок с помощью RAR, проверяет целостность архивов, управляет ротацией старых файлов и отправляет отчёты по электронной почте.

### Ключевые особенности

- **Безопасность:** Проверка SHA256-хешей конфигурационного XML и rar.exe перед запуском
- **Три режима архивации:**
  - Обычная (все файлы источника в один архив)
  - Индивидуальная файловая (каждый файл в отдельный архив)
  - Индивидуальная папочная (каждая подпапка в отдельный архив)
- **Верификация:** Сравнение содержимого архива с источником перед удалением оригиналов
- **Ротация:** Автоматическое удаление старых файлов по возрасту и количеству
- **Отчётность:** XML-отчёты, лог-файлы, email-уведомления, Event Log Windows
- **Тестовый режим:** Проверка конфигурации без выполнения архивации (`-TestMode`)

---

## Текущий список функций

- **Test-StringIsNullOrWhiteSpace** — Замена `[string]::IsNullOrWhiteSpace` для PS 2.0
- **Get-FileHashCompat** — Вычисление хешей файлов (SHA1/SHA256/MD5 и др.)
- **Test-FileIntegrity** — Проверка целостности файлов по SHA256
- **Initialize-Logging** — Инициализация системы логирования
- **Write-Log** — Запись сообщений в лог с уровнями
- **Get-LogFilePath** — Получение пути к текущему файлу лога
- **Write-LogSection** — Визуальные разделители в логе
- **Get-LogResults** — Получение отмеченных записей для отчёта
- **Write-WinEventAppLog** — Запись событий в Event Log Windows
- **Get-RarExitCodeMeaning** — Интерпретация кодов возврата RAR
- **Start-RarArchive** — Запуск архивации через RAR.exe
- **Test-RarArchive** — Проверка целостности RAR-архива
- **Get-FileInfoDetails** — Детали о файлах директории (количество, размер)
- **Copy-BackupFile** — Копирование с проверкой по размеру
- **Start-IndividualFileArchive** — Индивидуальная архивация каждого файла
- **Start-IndividualFolderArchive** — Индивидуальная архивация каждой папки
- **Get-CanonicalPath** — Нормализация и получение относительного пути
- **Get-CommonPathPrefix** — Нахождение общего префикса путей
- **Get-FileList** — Рекурсивное сканирование файлов
- **Get-FilterFileList** — Поиск файлов по маске
- **Get-FileArhListRar** — Чтение содержимого RAR-архива
- **ConvertFrom-RarListOutput** — Парсинг вывода RAR в объекты
- **Compare-FilesSourceArchive** — Сравнение источника и архива
- **Write-BackupXmlReport** — Создание XML-отчёта по заданию
- **Write-HostSummary** — Сводный XML-отчёт по всем заданиям
- **Remove-OldFiles** — Ротация старых файлов
- **Send-Email** — Отправка почты через CDO
- **Get-BackupConfiguration** — Получение разрешённой конфигурации
- **Test-Configuration** — Валидация конфигурации
- **Get-DiskSpaceReport** — Информация о дисках компьютера
- **Format-FileSize** — Форматирование размера файла

Подробное описание функций: [description_of_functions/](description_of_functions/)

---

## Логика работы скрипта

### Общая схема выполнения

```plantuml
@startuml
skinparam backgroundColor #F5F5F5
skinparam activityBackgroundColor #FFFFFF
skinparam activityBorderColor #333333
skinparam activityBorderThickness 2
skinparam defaultFontSize 14
skinparam defaultFontName Arial

start

:Запуск скрипта;
note right: powershell.exe -executionpolicy RemoteSigned -file .\Backup-rar-ps2.ps1

partition "ЭТАП 0: Проверка XML" {
    :Поиск Backup-Config-All.xml;
    if (XML найден?) then (нет)
        :КРИТИЧЕСКАЯ ОШИБКА;\nexit 1;
        stop
    else (да)
        :Test-FileIntegrity()\nSHA256 хеш XML;
        if (Хеш совпадает?) then (нет)
            :ПРОВЕРКА ПРОВАЛЕНА;\nexit 1;
            stop
        else (да)
            :XML проверен успешно;
        endif
    endif
}

partition "Загрузка конфигурации" {
    :Чтение XML (Get-Content);\nПарсинг в [xml]$xmlDoc;
    :Проверка ArchiverType == "RAR";
    if (Тип = RAR?) then (нет)
        :КРИТИЧЕСКАЯ ОШИБКА;\nexit 1;
        stop
    else (да)
        :Формирование $BackupConfig\nи $config хеш-таблиц;
        :Извлечение переменных:\nPCName, SmtpServer, AdminMail и т.д.;
    endif
}

partition "ЭТАП 1: Проверка архиватора" {
    :Получение пути к rar.exe из конфига;
    :Test-FileIntegrity()\nSHA256 хеш rar.exe;
    if (Хеш совпадает?) then (нет)
        :ПРОВЕРКА ПРОВАЛЕНА;\nexit 1;
        stop
    else (да)
        :Архиватор RAR проверен;
    endif
}

partition "ЭТАП 2: Основной запуск" {
    if (Режим -TestMode?) then (да)
        :ТЕСТОВЫЙ РЕЖИМ;
        :Проверка архиватора;\nПроверка источников;\nПроверка прав записи;\nПроверка SMTP;\nПроверка получателей;
        :Отправка тестового письма;\nexit;
        stop
    else (нет)
        :Initialize-Logging()\nСоздание лог-файла;
        :Write-LogSection "ЗАПУСК СКРИПТА";
        :Test-Configuration()\nВалидация конфигурации;
        if (Конфиг валиден?) then (нет)
            :Вывод ошибок;\nexit 1;
            stop
        else (да)
            :Write-WinEventAppLog "Start";
        endif
    endif
}

partition "Цикл обработки заданий" {
    :foreach ($jobName in $config['Jobs'].Keys);
    repeat
        :Write-LogSection "ЗАДАНИЕ: $jobName";
        :Проверка/создание директорий\n(Source, LocalDest, RemoteDest);
        :Get-FileInfoDetails()\nАнализ источника;

        if (Есть SourceCheckMasks?) then (да)
            :Get-FilterFileList()\nПроверка файлов по маскам;
        endif

        if (ListSourceFlag?) then (да)
            :Get-FileList()\nФормирование списка файлов (txt/csv);
        endif

        if (ArchiveIndividualFiles?) then (да)
            :ИНДИВИДУАЛЬНАЯ АРХИВАЦИЯ ФАЙЛОВ;
            :Start-IndividualFileArchive();
        elseif (ArchiveIndividualFolders?) then (да)
            :ИНДИВИДУАЛЬНАЯ АРХИВАЦИЯ ПАПОК;
            :Start-IndividualFolderArchive();
        else (нет)
            :ОБЫЧНАЯ АРХИВАЦИЯ;
            :Start-RarArchive();
        endif

        :Test-RarArchive()\nПроверка целостности архива;

        if (Обычная архивация) then (да)
            :Get-FileList() / Get-FilterFileList();
            :Get-FileArhListRar();
            :Compare-FilesSourceArchive();
            if (Верификация пройдена?) then (нет)
                :ОШИБКА: Нарушение целостности;
            else (да)
                :ВЕРИФИКАЦИЯ ПРОЙДЕНА;
            endif
        endif

        if (RemoteDest доступен?) then (да)
            :Copy-BackupFile()\nКопирование в сетевое хранилище;
            if (RemoveRemoteDestFlag?) then (да)
                :Remove-OldFiles()\nРотация удалённого хранилища;
            endif
        else (нет)
            :WARNING: Сохранено только локально;
        endif

        :Remove-OldFiles()\nРотация локального хранилища;

        if (RemoveSourceFlag?) then (да)
            if (Индивидуальный режим) then (да)
                :ВЕРИФИКАЦИЯ ПЕРЕД УДАЛЕНИЕМ;\nCompare-FilesSourceArchive()\nдля каждого архива;
                if (Все прошли?) then (да)
                    :Удаление проверенных файлов/папок;
                else (нет)
                    :WARNING: Удаление ОТМЕНЕНО;
                endif
            else (нет)
                :Remove-OldFiles()\nРотация источника;
            endif
        endif

        :Write-BackupXmlReport()\nXML-отчёт по заданию;
        :Write-Log "Задание завершено";
    repeat while (Есть ещё задания?) is (да)
    -> нет;
}

partition "Финальные результаты" {
    :Remove-OldFiles()\nОчистка старых логов;
    :Get-DiskSpaceReport()\nДиагностика дисков;
    :Write-LogSection "ФИНАЛЬНЫЕ РЕЗУЛЬТАТЫ";
    :Write-HostSummary()\nСводный XML-отчёт;
    :Get-LogResults()\nФормирование текста письма;

    if (Есть ошибки?) then (да)
        :Subject = "...ОБНАРУЖЕНЫ ОШИБКИ";\nПолучатели: AdminIS, AdminOS;
        :Write-WinEventAppLog "Error";
    else (нет)
        :Subject = "...УСПЕХ";\nПолучатели: AdminIS, AdminMail;
        :Write-WinEventAppLog "Success";
    endif

    :Send-Email()\nОтправка отчёта по почте;
    :Write-WinEventAppLog "End";

    if (errorCount > 0) then (да)
        :exit 1;
    else (нет)
        :exit 0;
    endif
}

stop
@enduml
```

---

### Режимы архивации

#### 1. Обычная архивация

Все файлы источника архивируются в единый RAR-архив.

```plantuml
@startuml
skinparam backgroundColor #F5F5F5

title Обычная архивация - последовательность

actor "Скрипт" as Script
participant "Source\n(источник)" as Source
participant "RAR.exe" as Rar
participant "LocalDest\n(локальный)" as Local
participant "RemoteDest\n(сетевой)" as Remote
database "Лог-файл" as Log

Script -> Source: Get-FileInfoDetails()\nАнализ файлов
Source --> Script: FileCount, TotalSize

Script -> Rar: Start-RarArchive()\na -m3 -s -ep1 -rr1p -r -dh -t
Rar -> Rar: Создание архива\nLocalDest\archive.rar
Rar --> Script: ExitCode, Duration, ArchiveSize

Script -> Rar: Test-RarArchive()\nПроверка целостности
Rar --> Script: IsValid

Script -> Source: Get-FileList()\nСписок файлов источника
Source --> Script: sourceFiles[]

Script -> Rar: Get-FileArhListRar()\nСписок файлов архива
Rar --> Script: archiveFiles[]

Script -> Script: Compare-FilesSourceArchive()\nСравнение sourceFiles vs archiveFiles

alt Верификация пройдена
    Script -> Log: ВЕРИФИКАЦИЯ ПРОЙДЕНА
    Script -> Remote: Copy-BackupFile()\nКопирование архива
    Remote --> Script: Success
    Script -> Local: Remove-OldFiles()\nРотация локальных архивов
else Верификация провалена
    Script -> Log: ОШИБКА: Нарушение целостности
    Script -> Script: throw Exception
end
@enduml
```

#### 2. Индивидуальная архивация файлов

Каждый файл, найденный по маске `SourceFilter`, архивируется в отдельный RAR.

```plantuml
@startuml
skinparam backgroundColor #F5F5F5

title Индивидуальная архивация файлов

actor "Скрипт" as Script
participant "Source" as Source
participant "RAR.exe" as Rar
participant "LocalDest" as Local
participant "RemoteDest" as Remote

Script -> Source: Get-FilterFileList()\nПоиск по маске (например *.xml)
Source --> Script: files[] (file1.xml, file2.xml, ...)

loop Для каждого файла
    Script -> Rar: Start-RarArchive()\nfile1.xml -> PC1_Job1_file1.rar
    Rar --> Script: ExitCode, ArchiveSize

    alt Успешно
        Script -> Local: Архив сохранён
    else Ошибка
        Script -> Script: Запись ошибки в результат
    end
end

Script -> Remote: Copy-BackupFile()\nКопирование всех архивов
Remote --> Script: Результаты копирования

opt RemoveSourceFlag
    Script -> Script: ВЕРИФИКАЦИЯ КАЖДОГО АРХИВА
    loop Для каждого успешного архива
        Script -> Rar: Get-FileArhListRar()
        Rar --> Script: archiveFiles[]
        Script -> Script: Compare-FilesSourceArchive()

        alt Верификация OK
            Script -> Source: Remove-Item()\nУдаление исходного файла
        else Верификация FAIL
            Script -> Script: Удаление ОТМЕНЕНО
        end
    end
end
@enduml
```

#### 3. Индивидуальная архивация папок

Каждая подпапка первого уровня архивируется в отдельный RAR.

```plantuml
@startuml
skinparam backgroundColor #F5F5F5

title Индивидуальная архивация папок

actor "Скрипт" as Script
participant "Source" as Source
participant "RAR.exe" as Rar
participant "LocalDest" as Local

Script -> Source: Get-ChildItem\nПодпапки первого уровня
Source --> Script: folders[] (folder1, folder2, ...)

opt FolderFilter
    Script -> Script: Фильтрация по маске
end

opt ExcludeFolderPattern
    Script -> Script: Исключение папок\n(спецзначение "today" = текущая дата)
end

loop Для каждой папки
    Script -> Rar: Start-RarArchive()\nfolder1 -> PC1_Job1_folder1.rar
    Rar --> Script: ExitCode, ArchiveSize

    alt Успешно
        Script -> Local: Архив сохранён
    else Ошибка
        Script -> Script: Запись ошибки в результат
    end
end

opt RemoveSourceFlag
    Script -> Script: ВЕРИФИКАЦИЯ КАЖДОГО АРХИВА
    loop Для каждого успешного архива
        Script -> Source: Get-FileList()\nФайлы папки
        Script -> Rar: Get-FileArhListRar()
        Rar --> Script: archiveFiles[]
        Script -> Script: Compare-FilesSourceArchive()

        alt Верификация OK
            Script -> Source: Remove-Item -Recurse\nУдаление папки
        else Верификация FAIL
            Script -> Script: Удаление ОТМЕНЕНО
        end
    end
end
@enduml
```

---

### Механизм верификации

Верификация гарантирует, что содержимое архива точно соответствует источнику.

```plantuml
@startuml
skinparam backgroundColor #F5F5F5
skinparam sequenceMessageAlign center

title Процесс верификации архива

participant "Источник\n(файлы)" as Source
participant "Архив\n(RAR)" as Archive
participant "Get-FileList" as GetSource
participant "Get-FileArhListRar" as GetArchive
participant "Compare-Files\nSourceArchive" as Compare
database "Результат" as Result

Source -> GetSource: Сканирование файлов\nRelativePath, Length
GetSource --> Compare: sourceList[]

Archive -> GetArchive: rar.exe vtb -cfg-\narchive.rar
GetArchive -> GetArchive: ConvertFrom-RarListOutput()\nПарсинг вывода
GetArchive --> Compare: archiveList[]

Compare -> Compare: Нормализация путей\n(Get-CanonicalPath)
Compare -> Compare: Хеш-таблицы по\nRelativePath (нижний регистр)

loop Для каждого файла источника
    alt Файл найден в архиве
        Compare -> Compare: Сравнение Length
        alt Размер совпадает
            note right: OK
        else Размер не совпадает
            Compare --> Result: SizeMismatch
        end
    else Файл НЕ найден в архиве
        Compare -> Compare: Поиск по суффиксу\n(EndsWith)
        alt Найден по суффиксу
            Compare -> Compare: Сравнение Length
        else Не найден
            Compare --> Result: MissingInArchive
        end
    end
end

loop Проверка лишних файлов
    alt Файл есть в архиве, но нет в источнике
        Compare --> Result: ExtraInArchive
    end
end

alt Все файлы совпали
    Result --> Result: IsIdentical = true\n"SUCCESS: Полное совпадение"
else Есть расхождения
    Result --> Result: IsIdentical = false\nОтчёт с ошибками
end
@enduml
```

---

### Система логирования

```plantuml
@startuml
skinparam backgroundColor #F5F5F5

package "Модуль логирования" {
    [Initialize-Logging] as Init
    [Write-Log] as Write
    [Write-LogSection] as Section
    [Get-LogFilePath] as GetPath
    [Get-LogResults] as GetResults
    [Write-WinEventAppLog] as EventLog
}

database "Лог-файл\n*.log" as LogFile
queue "ReportEntries\n(массив)" as Report
database "Event Log\nApplication" as WinEvent

Init -> LogFile: Создание файла\n{PCName}_{JobName}_{timestamp}.log
Init --> Report: Инициализация @()

Write -> LogFile: AppendAllText()\n[timestamp] [LEVEL] message
Write -> Report: += logEntry\n(если -ResultKey)

Section -> LogFile: AppendAllText()\n=== ЗАГОЛОВОК ===

GetPath --> LogFile: Возврат пути

GetResults --> Report: Join("\r\n")\nОбъединение записей

EventLog -> WinEvent: WriteEntry()\nEventId: 3000-3004
@enduml
```

---

### Ротация файлов

```plantuml
@startuml
skinparam backgroundColor #F5F5F5

title Алгоритм ротации (Remove-OldFiles)

start

:Get-ChildItem -Path $Path\n-Filter $Filter;
note right: Только файлы, без рекурсии

:Sort-Object LastWriteTime\n-Descending;
note right: Новые сверху

:Расчёт cutoffDate\n= (Get-Date).AddDays(-$DaysOld);

:Выбор файлов для сохранения:\nSelect-Object -First $KeepCount;
note right: Сохраняем последние N файлов

:Выбор файлов для удаления:\nLastWriteTime < cutoffDate\nИ НЕ входят в KeepCount;

if (Есть файлы для удаления?) then (да)
    :foreach ($file in $filesToDelete);
    :Remove-Item $file -Force;
    :Write-Log "Удален: $($file.Name)";
    -> нет;
else (нет)
endif

:Логирование:\nНайдено / Удалено / Сохранено;

stop
@enduml
```

---

### Отправка email-отчёта

```plantuml
@startuml
skinparam backgroundColor #F5F5F5

title Процесс отправки email

start

:Get-LogResults()\nТекст отчёта из ReportEntries;

if (errorCount > 0?) then (да)
    :Subject = "$PCName $ParentJobName : ОБНАРУЖЕНЫ ОШИБКИ";
    :To = $AdminIS, $AdminOS;
    :Body = "Ошибки в процессе:\n" + $EmailTextBody;
    :Write-WinEventAppLog "Error";
else (нет)
    :Subject = "$PCName $ParentJobName : УСПЕХ";
    :To = $AdminIS, $AdminMail;
    :Body = "Задание выполнено успешно:\n" + $EmailTextBody;
    :Write-WinEventAppLog "Success";
endif

:Send-Email();
note right
    COM-объект CDO.Message
    SmtpServer, Port 25
    Анонимная аутентификация
end note

if (Отправка успешна?) then (да)
    :Письмо успешно отправлено;
else (нет)
    :Ошибка отправки письма;
endif

:Write-WinEventAppLog "End";

stop
@enduml
```

---

### Переменные шаблона ArchivePattern

При формировании имён архивов поддерживаются следующие переменные:

| Переменная | Описание | Пример |
|------------|----------|--------|
| `{PCName}` | Имя компьютера | `SERVER01` |
| `{JobName}` | Имя дочернего задания | `BackupLogs` |
| `{Date}` | Дата в формате YYYYMMDD | `20260410` |
| `{Time}` | Время в формате HHMMSS | `143025` |
| `{Date_Time}` | Дата и время | `20260410_143025` |
| `{SourceFileName}` | Имя исходного файла | `report.xml` |
| `{SourceFolderName}` | Имя исходной папки | `20260409` |

**Пример:**  
`{PCName}_{JobName}_{Date_Time}.rar` → `SERVER01_BackupLogs_20260410_143025.rar`

---

## Структура XML-конфигурации

```xml
<?xml version="1.0" encoding="utf-8"?>
<BackupConfig>
    <General>
        <JobName>BackupAllXml</JobName>
        <Domain>company.local</Domain>
        <SmtpServer>mail.company.local</SmtpServer>
        <LogDaysOld>30</LogDaysOld>
        <LogKeepCount>10</LogKeepCount>
        <ArchiverType>RAR</ArchiverType>
        <DefaultRarParameters>
            <Param>a</Param>
            <Param>-m3</Param>
            <Param>-s</Param>
            <Param>-ep1</Param>
            <Param>-rr1p</Param>
            <Param>-r</Param>
            <Param>-dh</Param>
            <Param>-t</Param>
        </DefaultRarParameters>
    </General>
    <Paths>
        <LogPathRoot>C:\Work\BackupAllXml\logs</LogPathRoot>
        <NetLogPath>\\server\logs</NetLogPath>
        <RarPath>C:\Work\BackupAllXml\rar.exe</RarPath>
    </Paths>
    <Recipients>
        <AdminIS>admin1@company.local</AdminIS>
        <AdminOS>admin2@company.local</AdminOS>
        <AdminMail>admin3@company.local</AdminMail>
    </Recipients>
    <Integrity>
        <RarExeHash>ABC123...DEF</RarExeHash>
    </Integrity>
    <Jobs>
        <Job>
            <Name>BackupJob1</Name>
            <Source>C:\Data\Source</Source>
            <LocalDest>C:\Work\BackupAllXml\backup</LocalDest>
            <RemoteDest>\\server\backup</RemoteDest>
            <ArchivePattern>{PCName}_{JobName}_{Date_Time}.rar</ArchivePattern>
            <RemoveSourceFlag>false</RemoveSourceFlag>
            <SourceDaysOld>7</SourceDaysOld>
            <SourceKeepCount>5</SourceKeepCount>
            <LocalDestDaysOld>30</LocalDestDaysOld>
            <LocalDestKeepCount>10</LocalDestKeepCount>
            <RemoveRemoteDestFlag>true</RemoveRemoteDestFlag>
            <RemoteDestDaysOld>90</RemoteDestDaysOld>
            <RemoteDestKeepCount>20</RemoteDestKeepCount>
            <ArhLog>true</ArhLog>
            <ArchiveIndividualFolders>false</ArchiveIndividualFolders>
            <ArchiveIndividualFiles>false</ArchiveIndividualFiles>
            <ArhParameters>
                <Param>a</Param>
                <Param>-m5</Param>
            </ArhParameters>
            <SourceCheckMasks>
                <Mask>*.xml</Mask>
                <Mask>*.bak</Mask>
            </SourceCheckMasks>
            <SourceFilter>*.xml</SourceFilter>
        </Job>
    </Jobs>
</BackupConfig>
```

---

## Запуск скрипта

### Обычный запуск
```powershell
powershell.exe -executionpolicy RemoteSigned -file .\Backup-rar-ps2.ps1
```

### Тестовый режим (проверка конфигурации)
```powershell
powershell.exe -executionpolicy RemoteSigned -file .\Backup-rar-ps2.ps1 -TestMode
```

### Из планировщика задач Windows
```
Программа: powershell.exe
Аргументы: -executionpolicy RemoteSigned -file "C:\Work\BackupAllXml\Backup-rar-ps2.ps1"
Начать в: C:\Work\BackupAllXml
```

---

## Получение HASH перед запуском

Для обновления хешей в конфигурации используйте:

```powershell
# Хеш XML-конфигурации
(Get-FileHash -Path ".\Backup-Config-All.xml" -Algorithm SHA256).Hash

# Хеш исполняемого файла RAR
(Get-FileHash -Path ".\rar.exe" -Algorithm SHA256).Hash
```

> **Примечание:** На PowerShell 2.0 используйте функцию `Get-FileHashCompat`, которая автоматически создаёт алиас `Get-FileHash`.