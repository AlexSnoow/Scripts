# Test-StringIsNullOrWhiteSpace

## Описание
Функция-заменитель для `[string]::IsNullOrWhiteSpace`, который отсутствует в PowerShell 2.0. Проверяет, является ли строка null, пустой или состоит только из пробельных символов.

## Синтаксис
```powershell
Test-StringIsNullOrWhiteSpace [-Value] <string>
```

## Параметры
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| Value | string | Да | Строка для проверки |

## Возвращаемое значение
`[bool]` - возвращает `$true`, если строка null, пустая или содержит только пробельные символы; иначе `$false`.

## Примеры использования
```powershell
# Проверка на null
Test-StringIsNullOrWhiteSpace -Value $null
# Результат: True

# Проверка на пустую строку
Test-StringIsNullOrWhiteSpace -Value ""
# Результат: True

# Проверка на строку с пробелами
Test-StringIsNullOrWhiteSpace -Value "   "
# Результат: True

# Проверка на строку с контентом
Test-StringIsNullOrWhiteSpace -Value "Hello"
# Результат: False
```

## Примечания
- Функция необходима для совместимости с PowerShell 2.0, где метод `[string]::IsNullOrWhiteSpace` ещё не был реализован
- Использует регулярное выражение `^\s*$` для detection строк, состоящих только из пробельных символов
- Применяется во всём скрипте для валидации конфигурационных параметров и путей
