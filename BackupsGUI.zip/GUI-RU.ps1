# === Флаг разработки ===
$DEVELOP = $FALSE  # TRUE = окно + консоль, FALSE = только окно

if (-not $DEVELOP) {
    # Скрыть консоль
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public class ConsoleHelper {
    [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@
    $hwnd = [ConsoleHelper]::GetConsoleWindow()
    if ($hwnd -ne 0) { [ConsoleHelper]::ShowWindow($hwnd, 0) } # 0 = скрыть
}

# UTF-8 для кириллицы
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase

# --- XAML интерфейс ---
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Менеджер резервного копирования" Height="500" Width="800">
  <Grid Margin="10">
    <Grid.RowDefinitions>
      <RowDefinition Height="*"/>
      <RowDefinition Height="50"/>
      <RowDefinition Height="100"/>
    </Grid.RowDefinitions>

    <!-- Таблица серверов -->
    <DataGrid x:Name="dgServers" Grid.Row="0" AutoGenerateColumns="False" SelectionMode="Extended" IsReadOnly="True">
      <DataGrid.Columns>
        <DataGridTextColumn Header="Сервер" Binding="{Binding name}" Width="*"/>
        <DataGridTextColumn Header="Задача" Binding="{Binding taskName}" Width="*"/>
        <DataGridTextColumn Header="Версия" Binding="{Binding version}" Width="*"/>
        <DataGridTextColumn Header="Расписание" Binding="{Binding schedule}" Width="*"/>
        <DataGridTextColumn Header="Статус" Binding="{Binding status}" Width="*"/>
      </DataGrid.Columns>
    </DataGrid>

    <!-- Кнопки -->
    <StackPanel Orientation="Horizontal" Grid.Row="1" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="0,5,0,5" >
      <Button x:Name="btnUpdate" Content="Обновить скрипты" Width="150" Margin="10,0"/>
      <Button x:Name="btnRun" Content="Запустить задачу" Width="150" Margin="10,0"/>
      <Button x:Name="btnRefresh" Content="Обновить статус" Width="150" Margin="10,0"/>
    </StackPanel>

    <!-- Просмотр логов -->
    <TextBox x:Name="txtLog" Grid.Row="2" Margin="0,5,0,0" TextWrapping="Wrap" VerticalScrollBarVisibility="Auto" IsReadOnly="True" FontFamily="Consolas"/>
  </Grid>
</Window>

"@

$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$Window = [Windows.Markup.XamlReader]::Load($reader)

# --- Находим элементы через FindName ---
$dgServers  = $Window.FindName("dgServers")
$btnUpdate  = $Window.FindName("btnUpdate")
$btnRun     = $Window.FindName("btnRun")
$btnRefresh = $Window.FindName("btnRefresh")
$txtLog     = $Window.FindName("txtLog")

# --- Пути тестовые ---
$ConfigPath   = "C:\Work\BackupsGUI\Backup-Tasks\Config\hosts.json"
$StatusFolder = "C:\Work\BackupsGUI\Backup-Tasks\Status"

# --- Загрузка данных из hosts.json ---
function Load-Hosts {
    $hosts = Get-Content $ConfigPath -Raw | ConvertFrom-Json
    $data = @()
    foreach ($server in $hosts.servers) {
        foreach ($task in $server.tasks) {
            $statusFile = Join-Path $StatusFolder "$($server.name).txt"
            $status = "Неизвестно"
            if (Test-Path $statusFile) { $status = Get-Content $statusFile -Tail 1 }
            $data += [PSCustomObject]@{
                name     = $server.name
                taskName = $task.taskId
                version  = $task.version
                schedule = $task.schedule
                status   = $status
            }
        }
    }
    return $data
}

# --- Привязка к DataGrid ---
$dgServers.ItemsSource = Load-Hosts

# --- Функция обновления статуса ---
function Refresh-Status {
    $dgServers.ItemsSource = $null
    $dgServers.ItemsSource = Load-Hosts
}

# --- Обработчики кнопок ---
$btnUpdate.Add_Click({
    $dgServers.SelectedItems | ForEach-Object {
        Write-Host "Обновляем скрипты на $($_.name)..."
        Invoke-Command -ComputerName $_.name -ScriptBlock { & "C:\Backup\agent\backup-updater.ps1" } -ErrorAction SilentlyContinue
    }
    Refresh-Status
})

$btnRun.Add_Click({
    $dgServers.SelectedItems | ForEach-Object {
        Write-Host "Запуск резервного копирования на $($_.name)..."
        Invoke-Command -ComputerName $_.name -ScriptBlock { & "C:\Backup\agent\backup-loader.ps1" } -ErrorAction SilentlyContinue
    }
    Refresh-Status
})

$btnRefresh.Add_Click({
    Refresh-Status
})

# --- Двойной клик для просмотра последнего лога ---
$dgServers.Add_MouseDoubleClick({
    $selected = $dgServers.SelectedItem
    if ($selected) {
        $logDir = "C:\Backup\logs"
        if (!(Test-Path $logDir)) { $txtLog.Text = "Логи не найдены"; return }
        $latestLog = Get-ChildItem $logDir -Filter "backup*.log" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($latestLog) {
            $txtLog.Text = Get-Content $latestLog.FullName -Tail 100 -Encoding UTF8 | Out-String
        } else {
            $txtLog.Text = "Логи не найдены"
        }
    }
})

# --- Показ окна ---
$Window.ShowDialog() | Out-Null
