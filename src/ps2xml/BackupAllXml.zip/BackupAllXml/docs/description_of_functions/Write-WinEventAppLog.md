# Write-WinEventAppLog

## Описание
Функция записи событий в журнал событий Windows (Event Log) приложения. Используется для регистрации ключевых этапов выполнения скрипта в системном журнале событий.

## Синтаксис
```powershell
Write-WinEventAppLog [-StatusKey] <string> [-MessageText] <string> [[-Source] <string>]
```

## Параметры
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| StatusKey | string | Да | Тип события: Start, Success, Warning, Error, End |
| MessageText | string | Да | Текст сообщения для записи в журнал |
| Source | string | Нет | Источник событий. По умолчанию: `$ParentJobName` |

## Маппинг StatusKey
| StatusKey | Event ID | Тип записи |
|-----------|----------|-----------|
| Start | 3000 | Information |
| Success | 3001 | Information |
| Warning | 3002 | Warning |
| Error | 3003 | Error |
| End | 3004 | Information |

## Возвращаемое значение
Нет возвращаемого значения. При ошибке записи в Event Log выводит предупреждение.

## Примеры использования
```powershell
# Запись о начале скрипта
Write-WinEventAppLog -StatusKey "Start" -MessageText "Начало работы скрипта: BackupAllXml"

# Запись об успешном завершении
Write-WinEventAppLog -StatusKey "Success" -MessageText "СКРИПТ ЗАВЕРШЕН УСПЕШНО"

# Запись об ошибке
Write-WinEventAppLog -StatusKey "Error" -MessageText "СКРИПТ ЗАВЕРШЕН С ОШИБКАМИ"

# Запись с пользовательским источником
Write-WinEventAppLog -StatusKey "Warning" -MessageText "Диск заполнен на 90%" -Source "CustomMonitor"
```

## Примечания
- Записывает события в журнал `Application`
- Перед записью проверяет, что источник зарегистрирован в системе
- Если источник не найден, выводит предупреждение и выходит без записи
- Использует .NET класс `System.Diagnostics.EventLog`
- Ошибки записи в Event Log не прерывают выполнение скрипта (только предупреждение)
- Требует предварительной регистрации источника через `New-EventLog` (обычно выполняется при установке)
- Используется для интеграции с системами мониторинга (SCOM, Zabbix и т.д.)
