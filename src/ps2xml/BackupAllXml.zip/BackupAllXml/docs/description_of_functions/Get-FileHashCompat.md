# Get-FileHashCompat

## Описание
Функция обеспечения совместимости для вычисления криптографических хешей файлов. Является аналогом cmdlet `Get-FileHash`, доступного только в PowerShell 4.0+, но реализованного с использованием .NET Framework для работы на PowerShell 2.0.

## Синтаксис
```powershell
Get-FileHashCompat [-Path] <string> [-Algorithm <string>]
Get-FileHashCompat -LiteralPath <string> [-Algorithm <string>]
```

## Параметры
| Параметр | Тип | Обязательный | ПараметрSetName | Описание |
|----------|-----|--------------|---------------|----------|
| Path | string | Да (Path) | Path | Путь к файлу для вычисления хеша. Поддерживает pipeline input |
| LiteralPath | string | Да (LiteralPath) | LiteralPath | Литеральный путь к файлу (без обработки wildcard) |
| Algorithm | string | Нет | Оба | Алгоритм хеширования: SHA1, SHA256, SHA384, SHA512, MD5. По умолчанию: SHA256 |

## Возвращаемое значение
`[PSObject]` с свойствами:
- `Hash` - строка хеша в верхнем регистре (hex)
- `Algorithm` - использованный алгоритм (верхний регистр)
- `Path` - полный разрешённый путь к файлу

## Примеры использования
```powershell
# Вычисление SHA256 хеша файла
Get-FileHashCompat -Path "C:\file.txt"
# Результат: @{Hash="ABC123..."; Algorithm="SHA256"; Path="C:\file.txt"}

# Вычисление MD5 через pipeline
"C:\file.txt" | Get-FileHashCompat -Algorithm MD5

# Использование LiteralPath
Get-FileHashCompat -LiteralPath "C:\path with [brackets]\file.txt" -Algorithm SHA1
```

## Примечания
- Использует классы из `System.Security.Cryptography` для вычисления хеша
- Автоматически создаётся алиас `Get-FileHash` при отсутствии встроенной команды (через `Set-Alias`)
- Поддерживает конвейерный ввод для параметра Path
- При ошибке чтения файла генерирует исключение с подробным сообщением
- Хеш возвращается в верхнем регистре без разделительных дефисов
