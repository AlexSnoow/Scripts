# Write-HostSummary

## Описание
Функция создания сводного XML-отчёта по всем заданиям резервного копирования на текущем хосте. Генерирует единый файл с результатами каждого задания и общей статистикой.

## Синтаксис
```powershell
Write-HostSummary [-Results] <hashtable> [-TotalDuration] <string> [-SuccessCount] <int> [-ErrorCount] <int>
```

## Параметры
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| Results | hashtable | Да | Хеш-таблица результатов по заданиям (ключ - имя задания, значение - текстовый результат) |
| TotalDuration | string | Да | Общая длительность выполнения скрипта |
| SuccessCount | int | Да | Количество успешно выполненных заданий |
| ErrorCount | int | Да | Количество заданий с ошибками |

## Структура XML
```xml
<?xml version="1.0" encoding="utf-8"?>
<HostSummary>
    <Host>COMPUTER01</Host>
    <LastRun>2026-04-10T14:35:00</LastRun>
    <TotalDuration>5.7 мин</TotalDuration>
    <SuccessCount>3</SuccessCount>
    <ErrorCount>1</ErrorCount>
    <Job name="BackupJob1" status="Success"/>
    <Job name="BackupJob2" status="Success"/>
    <Job name="BackupJob3" status="Error" error="Ошибка архивации: Недопустимая команда"/>
    <Job name="BackupJob4" status="Warning"/>
</HostSummary>
```

## Примеры использования
```powershell
# Создание сводного отчёта
$results = @{
    "BackupJob1" = "Успешно: 150 файлов"
    "BackupJob2" = "Успешно: 50 архивов"
    "BackupJob3" = "Ошибка: Недопустимая команда"
}

Write-HostSummary `
    -Results $results `
    -TotalDuration "5.7 мин" `
    -SuccessCount 2 `
    -ErrorCount 1
```

## Определение статуса задания
Функция анализирует текстовый результат задания и определяет статус:
- Содержит "Ошибка" или "Error" → `status="Error"` (с атрибутом `error`)
- Содержит "ВНИМАНИЕ" или "WARNING" → `status="Warning"`
- Иначе → `status="Success"`

## Примечания
- Файл сохраняется как `{PCName}_summary.xml` в директории логов
- Автоматически экранирует XML-символы в сообщениях об ошибках
- Используется на финальном этапе скрипта для формирования общего отчёта
- Файл перезаписывается при каждом запуске (не добавляется)
- Может использоваться системами мониторинга для быстрого анализа результатов
- При ошибке записи выводит предупреждение (не прерывает выполнение)
