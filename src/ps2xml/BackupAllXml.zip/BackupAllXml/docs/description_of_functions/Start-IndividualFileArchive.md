# Start-IndividualFileArchive

## Описание
Функция индивидуальной архивации каждого файла, найденного по указанной маске, в отдельный RAR-архив. Позволяет создавать отдельные архивы для каждого файла источника с использованием настраиваемого шаблона именования.

## Синтаксис
```powershell
Start-IndividualFileArchive -ArchiverType <string> -ArchiverPath <string> -SourcePath <string> -DestinationPath <string> -FileFilter <string> -ArchivePattern <string> [-ExcludeFilePattern <string>] [-Parameters <string[]>] [-LogPath <string>] [-PCName <string>] [-JobName <string>]
```

## Параметры
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| ArchiverType | string | Да | Тип архиватора (поддерживается только "RAR") |
| ArchiverPath | string | Да | Путь к rar.exe |
| SourcePath | string | Да | Путь к директории источника |
| DestinationPath | string | Да | Путь к директории назначения для архивов |
| FileFilter | string | Да | Маска поиска файлов (например, `*.xml`, `*.bak`) |
| ArchivePattern | string | Да | Шаблон именования архивов (например, `{PCName}_{JobName}_{SourceFileName}.rar`) |
| ExcludeFilePattern | string | Нет | Маска исключения файлов |
| Parameters | string[] | Нет | Параметры для RAR.exe |
| LogPath | string | Нет | Путь к файлу лога архиватора |
| PCName | string | Нет | Имя компьютера (для замены в шаблоне) |
| JobName | string | Нет | Имя задания (для замены в шаблоне) |

## Шаблоны ArchivePattern
Поддерживает следующие переменные:
- `{PCName}` - имя компьютера
- `{JobName}` - имя задания
- `{SourceFileName}` - имя исходного файла

## Возвращаемое значение
`[PSObject[]]` - массив объектов результатов архивации, каждый со свойствами:
- `SourceFile` - имя исходного файла
- `SourceFileFullName` - полный путь к исходному файлу
- `ArchivePath` - полный путь к созданному архиву
- `ArchiveSize` - размер архива в МБ
- `Duration` - длительность архивации файла (секунды)
- `Status` - статус: 'Success' или 'Error'
- `ExitCode` - код возврата RAR.exe
- `ErrorMessage` - сообщение об ошибке (для статуса 'Error')

## Примеры использования
```powershell
# Индивидуальная архивация всех XML-файлов
$results = Start-IndividualFileArchive `
    -ArchiverType "RAR" `
    -ArchiverPath "C:\rar.exe" `
    -SourcePath "C:\data\source" `
    -DestinationPath "C:\backup\rar" `
    -FileFilter "*.xml" `
    -ArchivePattern "{PCName}_{JobName}_{SourceFileName}.rar" `
    -PCName "SERVER01" `
    -JobName "BackupJob"

foreach ($result in $results) {
    Write-Host "$($result.SourceFile): $($result.Status)"
}
```

## Примечания
- Находит файлы по маске через `Get-FilterFileList`
- При наличии `ExcludeFilePattern` фильтрует найденные файлы на исключение
- Для каждого файла создаёт отдельный архив
- Автоматически создаёт директорию назначения, если не существует
- Если шаблон не заканчивается на `.rar`, добавляет расширение автоматически
- Заменяет недопустимые символы в имени архива (`\/:*?"<>|`) на подчёркивание
- При ошибке архивации одного файла продолжает обработку остальных
- Возвращает результаты для всех файлов (успешных и с ошибками)
- Подсчитывает и логирует общую статистику (успешно/ошибки)
