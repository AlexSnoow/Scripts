# Write-BackupXmlReport

## Описание
Функция создания XML-отчёта о выполненном задании резервного копирования. Генерирует структурированный XML-файл с информацией о статусе задания, длительности, количестве файлов, размере архива и ошибках.

## Синтаксис
```powershell
Write-BackupXmlReport [-JobName] <string> [-JobStatus] <string> [-Duration] <string> [[-SourceFiles] <int>] [[-ArchiveSizeMB] <double>] [[-Verification] <string>] [[-Errors] <string[]>] [[-Warnings] <string[]>] [[-LogPath] <string>]
```

## Параметры
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| JobName | string | Да | Имя задания резервного копирования |
| JobStatus | string | Да | Статус задания: Success, Error, Warning |
| Duration | string | Да | Длительность выполнения (например, "2.35 мин") |
| SourceFiles | int | Нет | Количество файлов источника. По умолчанию: 0 |
| ArchiveSizeMB | double | Нет | Размер архива в МБ. По умолчанию: 0 |
| Verification | string | Нет | Статус верификации: Passed, Failed, Skipped. По умолчанию: Skipped |
| Errors | string[] | Нет | Массив сообщений об ошибках |
| Warnings | string[] | Нет | Массив предупреждений |
| LogPath | string | Нет | Путь к файлу лога |

## Структура XML
```xml
<?xml version="1.0" encoding="utf-8"?>
<BackupReport>
    <Host>COMPUTER01</Host>
    <Job>BackupJob</Job>
    <Timestamp>2026-04-10T14:30:25</Timestamp>
    <Status>Success</Status>
    <Duration>2.35 мин</Duration>
    <SourceFiles>150</SourceFiles>
    <ArchiveSizeMB>256.7</ArchiveSizeMB>
    <Verification>Passed</Verification>
    <Errors/>
    <Warnings/>
    <LogPath>C:\Logs\log.log</LogPath>
</BackupReport>
```

## Примеры использования
```powershell
# Создание отчёта об успешном задании
Write-BackupXmlReport `
    -JobName "BackupJob" `
    -JobStatus "Success" `
    -Duration "2.35 мин" `
    -SourceFiles 150 `
    -ArchiveSizeMB 256.7 `
    -Verification "Passed" `
    -LogPath "C:\Logs\log.log"

# Создание отчёта с ошибками
Write-BackupXmlReport `
    -JobName "BackupJob" `
    -JobStatus "Error" `
    -Duration "1.2 мин" `
    -Errors @("Файл не найден", "Ошибка архивации") `
    -Warnings @("Диск заполнен на 90%")
```

## Примечания
- Файл отчёта сохраняется в директории логов с именем `{PCName}_{JobName}_{Timestamp}.xml`
- Автоматически создаёт директорию, если не существует
- Экранирует специальные XML-символы (`&`, `<`, `>`) в сообщениях
- Использует `StringBuilder` для эффективной сборки XML
- При ошибке записи выводит предупреждение (не прерывает выполнение)
- Используется после каждого задания для формирования индивидуального отчёта
- XML-отчёты могут использоваться для аудита и анализа истории резервного копирования
